#pragma once
#include <vector>
#include <WinSock2.h>
#include "LKZ/Session/Client.h"

class MatchmakingManager
{
public:
    static void AddPlayerToQueue(Client& playerAddr);
    static void RemovePlayerFromQueue(const sockaddr_in& addr);
    static void ProcessMatchmaking();
private:
    static std::vector<Client> waitingPlayers;


};
