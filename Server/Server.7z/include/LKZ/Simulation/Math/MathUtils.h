#pragma once
#include "Vector.h"


static class MathUtils
{
private:

public:
	static float Distance(Vector2 a, Vector2 b);
	static float Distance(Vector3 a, Vector3 b);
};
